export type Crystal = {
  id: string;
  name: string;
  nameEn: string;
  description: string;
  origin: string;
  chakra: string;
  energyNote: string;
  priceUsd: number;
  imageUrl: string;
  videoUrl?: string;
};

export const crystals: Crystal[] = [
  {
    id: "himalayan-clear-001",
    name: "喜馬拉雅山透體水晶簇",
    nameEn: "Himalayan Clear Quartz Cluster",
    description:
      "清透且帶有細緻冰裂紋理的水晶簇，山脈呼吸般的紋路在光下層層展開，適合作為靜心空間的中心石。",
    origin: "喜馬拉雅山礦區",
    chakra: "頂輪 · 眉心輪",
    energyNote: "協助意識澄澈、提升靈性覺察，適合靜坐、冥想與能量工作。",
    priceUsd: 380,
    imageUrl: "https://your-cloudflare-images-domain/example-himalayan-clear.jpg"
  },
  {
    id: "tibetan-phantom-001",
    name: "藏晶四季幽靈",
    nameEn: "Tibetan Phantom Quartz",
    description:
      "晶體內部層層堆疊的幽靈幻影，如同季節更迭，承載長年能量沉澱，為靈魂帶來溫柔而堅定的支持。",
    origin: "西藏阿里礦區",
    chakra: "心輪 · 太陽神經叢",
    energyNote: "協助釋放舊有情緒模式，讓心重新與大地頻率對齊。",
    priceUsd: 420,
    imageUrl: "https://your-cloudflare-images-domain/example-tibetan-phantom.jpg"
  },
  {
    id: "himalayan-smoky-001",
    name: "喜馬拉雅煙晶守護石",
    nameEn: "Himalayan Smoky Guardian",
    description:
      "深色而穩重的煙晶調性，承接高山厚實能量，適合作為空間守護與個人防護石。",
    origin: "喜馬拉雅山高海拔帶",
    chakra: "海底輪 · 臍輪",
    energyNote: "穩定氣場、釋放壓力，幫助將高頻能量真正落實到日常生活。",
    priceUsd: 360,
    imageUrl: "https://your-cloudflare-images-domain/example-himalayan-smoky.jpg"
  }
];
