import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Luminara | 光魂晶宇",
  description: "來自世界屋脊的光，為靈魂而生。Himalayan & Tibetan high-frequency crystals by Luminara."
};

export default function RootLayout({
  children
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="zh-Hant">
      <body className="min-h-screen bg-luminara-bg text-luminara-soft font-body antialiased">
        {children}
      </body>
    </html>
  );
}
