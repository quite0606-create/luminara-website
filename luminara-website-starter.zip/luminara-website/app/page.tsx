import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { HeroSection } from "@/components/HeroSection";
import Link from "next/link";

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        <HeroSection />

        <section id="about" className="section space-y-6 border-y border-white/5">
          <p className="text-xs tracking-[0.35em] uppercase text-luminara-gold">
            Brand Story · Luminara 光魂晶宇
          </p>
          <div className="grid gap-10 md:grid-cols-[3fr,2fr]">
            <div className="space-y-4 text-sm leading-relaxed text-luminara-soft/75">
              <p>
                Luminara 光魂晶宇專注於喜馬拉雅山與西藏等高海拔地區的高頻水晶選品。
                在嚴苛環境中成長的晶礦，常伴隨礦傷、冰裂與天然紋理，我們選擇如實呈現這些「不完美」，因為那正是靈魂與山脈共同寫下的故事。
              </p>
              <p>
                本階段網站僅展示水晶，不上線隕石相關品項。
                未來若開放隕石與其他礦種，我們也會在不違背大地節奏的前提下，慎重地將牠們介紹給你。
              </p>
              <p>
                我們相信，真正高頻的能量，不是炫耀，而是幫助你回到自己——
                <span className="text-luminara-gold/90">
                  Return to Light, Return to Earth.
                </span>
              </p>
            </div>
            <div className="space-y-4 rounded-3xl border border-white/10 bg-gradient-to-br from-white/5 via-black to-black/90 p-6 text-xs text-luminara-soft/70 shadow-soft-glow">
              <p className="text-[11px] tracking-[0.25em] uppercase text-luminara-gold">
                HOW TO EXPERIENCE · 如何與水晶相遇
              </p>
              <ol className="space-y-3 list-decimal list-inside">
                <li>先看整體形態與氣場，而不是只看瑕疵。</li>
                <li>留意你第一眼被吸引的那顆——那通常不是偶然。</li>
                <li>輕輕閉眼，將注意力放在呼吸與胸口，感受牠帶來的是安定、擴張，還是被看見。</li>
              </ol>
              <p>
                若你有想要針對七脈輪、靈性覺醒或日常守護配置水晶套組，也可以透過{" "}
                <span className="text-luminara-gold">Email / IG 私訊</span> 與我們討論。
              </p>
              <Link
                href="/products"
                className="inline-flex rounded-full border border-luminara-gold/60 px-5 py-2 text-[10px] tracking-[0.3em] uppercase text-luminara-gold hover:bg-luminara-gold/10"
              >
                Explore Crystals · 前往水晶一覽
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
