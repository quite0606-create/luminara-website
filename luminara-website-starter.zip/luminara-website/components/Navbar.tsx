import Link from "next/link";

export function Navbar() {
  return (
    <header className="sticky top-0 z-20 border-b border-white/5 bg-black/40 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <Link href="/" className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-full border border-luminara-gold/60 bg-gradient-to-br from-luminara-gold/40 to-transparent shadow-soft-glow" />
          <div className="leading-tight">
            <div className="text-xs tracking-[0.35em] uppercase text-luminara-gold">
              Luminara
            </div>
            <div className="text-sm text-luminara-soft/80">光魂晶宇</div>
          </div>
        </Link>
        <nav className="flex items-center gap-6 text-xs tracking-[0.25em] uppercase">
          <Link href="/products" className="text-luminara-soft/70 hover:text-luminara-gold">
            Crystals 水晶
          </Link>
          <a
            href="#about"
            className="text-luminara-soft/50 hover:text-luminara-gold"
          >
            About 品牌故事
          </a>
        </nav>
      </div>
    </header>
  );
}
