"use client";

import { crystals } from "@/data/products";
import { useRouter } from "next/navigation";

export function ProductGrid() {
  const router = useRouter();

  return (
    <section className="section">
      <div className="mb-8 space-y-3">
        <p className="text-xs tracking-[0.35em] uppercase text-luminara-gold">
          Crystal Collection
        </p>
        <h1 className="font-display text-2xl text-luminara-soft">
          高頻水晶選品 · CRYSTALS
        </h1>
        <p className="max-w-2xl text-sm text-luminara-soft/70">
          目前網站僅展示喜馬拉雅山與藏晶等高頻水晶，隕石與其他礦種將在未來階段再開放。
          每一顆皆為實品獨照、不做過度修圖。
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-3">
        {crystals.map((c) => (
          <article
            key={c.id}
            className="flex flex-col overflow-hidden rounded-3xl border border-white/10 bg-white/5/10 p-4 shadow-soft-glow"
          >
            <div className="aspect-[3/4] overflow-hidden rounded-2xl border border-white/10 bg-black/40">
              <img
                src={c.imageUrl}
                alt={c.name}
                className="h-full w-full object-cover"
              />
            </div>
            <div className="mt-4 flex flex-1 flex-col gap-2 text-sm">
              <div className="space-y-1">
                <div className="text-xs tracking-[0.25em] uppercase text-luminara-gold">
                  {c.nameEn}
                </div>
                <div className="text-base text-luminara-soft">{c.name}</div>
                <div className="text-xs text-luminara-soft/60">{c.origin}</div>
              </div>
              <p className="text-xs leading-relaxed text-luminara-soft/70">
                {c.description}
              </p>
              <div className="mt-2 text-xs text-luminara-soft/60">
                脈輪：{c.chakra}
                <br />
                能量備註：{c.energyNote}
              </div>
              <div className="mt-4 flex items-center justify-between">
                <div className="text-sm text-luminara-gold">
                  USD {c.priceUsd.toFixed(0)}
                </div>
                <button
                  onClick={() => {
                    router.push("mailto:your@email?subject=Luminara Crystal " + c.id);
                  }}
                  className="rounded-full border border-luminara-gold/60 px-4 py-2 text-[10px] tracking-[0.25em] uppercase text-luminara-gold hover:bg-luminara-gold/10"
                >
                  Inquire 詢問此晶石
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
