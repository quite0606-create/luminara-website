export function Footer() {
  return (
    <footer className="border-t border-white/5">
      <div className="section flex flex-col gap-3 py-10 text-xs text-luminara-soft/50">
        <div className="tracking-[0.25em] uppercase">
          Return to Light, Return to Earth.
        </div>
        <div className="text-luminara-soft/60">
          讓靈魂與地球，共同振動於愛的頻率。
        </div>
        <div className="text-luminara-soft/40">
          © {new Date().getFullYear()} Luminara 光魂晶宇 · All rights reserved.
        </div>
      </div>
    </footer>
  );
}
