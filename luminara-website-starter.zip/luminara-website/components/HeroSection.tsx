import Link from "next/link";

export function HeroSection() {
  return (
    <section className="section flex flex-col items-start gap-10 pb-10 pt-20 md:flex-row md:items-center">
      <div className="flex-1 space-y-6">
        <p className="text-xs tracking-[0.35em] uppercase text-luminara-gold">
          Light from the Roof of the World
        </p>
        <h1 className="max-w-xl font-display text-4xl tracking-wide text-luminara-soft md:text-5xl">
          來自世界屋脊的光，
          <br />
          為靈魂而生。
        </h1>
        <p className="max-w-xl text-sm leading-relaxed text-luminara-soft/70">
          精選喜馬拉雅山與西藏高頻水晶，每一顆都在嚴苛環境中誕生，帶著山脈的呼吸與祂自己的靈魂。
          我們尊重每一道冰裂、每一處礦痕，因為那是牠們走過的路。
        </p>
        <div className="flex flex-wrap gap-4">
          <Link
            href="/products"
            className="rounded-full border border-luminara-gold/60 bg-luminara-gold/10 px-6 py-3 text-xs tracking-[0.3em] uppercase text-luminara-gold shadow-soft-glow hover:bg-luminara-gold/20"
          >
            View Crystals 水晶一覽
          </Link>
          <a
            href="#about"
            className="rounded-full border border-white/10 px-6 py-3 text-xs tracking-[0.3em] uppercase text-luminara-soft/70 hover:border-luminara-gold/40 hover:text-luminara-gold"
          >
            Brand Story 品牌故事
          </a>
        </div>
      </div>
      <div className="mt-10 flex flex-1 justify-center md:mt-0">
        <div className="relative h-80 w-64 overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-white/5 via-white/0 to-luminara-gold/10 shadow-soft-glow">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_0,rgba(233,216,166,0.18),transparent_55%),radial-gradient(circle_at_80%_100%,rgba(148,163,184,0.18),transparent_55%)]" />
          <div className="absolute inset-6 flex flex-col justify-between text-xs">
            <div className="space-y-1">
              <div className="tracking-[0.25em] uppercase text-luminara-gold">
                Himalayan Crystal
              </div>
              <div className="text-luminara-soft/70">喜馬拉雅山水晶 · 高頻能量</div>
            </div>
            <div className="space-y-2 text-[10px] text-luminara-soft/60">
              <p>每一顆晶礦，都是地球在極端環境下寫給靈魂的信。</p>
              <p className="text-luminara-gold/80">
                尊重礦傷，尊重牠們走過的路。
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
