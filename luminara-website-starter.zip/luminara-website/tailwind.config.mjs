/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ["ui-serif", "Georgia", "serif"],
        body: ["system-ui", "sans-serif"]
      },
      colors: {
        luminara: {
          bg: "#050608",
          gold: "#E9D8A6",
          soft: "#F5F1E8"
        }
      },
      boxShadow: {
        "soft-glow": "0 0 60px rgba(233, 216, 166, 0.18)"
      }
    }
  },
  plugins: []
};
